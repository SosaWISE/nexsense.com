<ul>
	<li rel="nexsense-system"><a href="nexsense-system.php">Nexsense System</a></li>
	<li rel="choose-your-system"><a href="choose-your-system.php">Choose Your System</a></li>
	<li rel="customer-service"><a href="customer-service.php">Customer Service</a></li>
	<li rel="about-us"><a href="about.php">About Us</a></li>
	<li rel="contact-us"><a href="contact.php">Contact Us</a></li>
</ul>