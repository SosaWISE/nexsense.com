<ul>
	<li rel="nexsense-system"><a href="nexsense-system">Nexsense System</a></li>
	<li rel="choose-your-system"><a href="choose-your-system">Choose Your System</a></li>
	<li rel="customer-service"><a href="customer-service">Customer Service</a></li>
	<li rel="about-us"><a href="about">About Us</a></li>
	<li rel="contact-us" class="last"><a href="contact">Contact Us</a></li>
</ul>